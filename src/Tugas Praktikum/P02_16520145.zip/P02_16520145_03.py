# Nama : Willy Wilsen
# NIM : 16520145
# Tanggal : 4 November 2020
# Deskripsi : Membuat program yang menggambarkan pola sebuah setengah kotak 2N*2N

# KAMUS
# N : int
# Asumsikan N > 0 dan N <= 10

# ALGORITMA
N = int(input("Masukkan bilangan: "))
print("Pola yang terbentuk:")
while N >= 1:
    for x in range(2*N):
        print(0, end = "")
    print("")
    N-=1
    
    print(0, end = "")
    for x in range(2*N):
        print(1, end = "")
    print(0)
    N-=1
    
    print(0, end = "")
    print(1, end = "")
    for x in range(2*N):
        print(2, end = "")
    print(1, end = "")
    print(0)
    N-=1

    print(0, end = "")
    print(1, end = "")
    print(2, end = "")
    for x in range(2*N):
        print(3, end = "")
    print(2, end = "")
    print(1, end = "")
    print(0)
    N-=1
    
    print(0, end = "")
    print(1, end = "")
    print(2, end = "")
    print(3, end = "")
    for x in range(2*N):
        print(4, end = "")
    print(3, end = "")
    print(2, end = "")
    print(1, end = "")
    print(0)
    N-=1

    print(0, end = "")
    print(1, end = "")
    print(2, end = "")
    print(3, end = "")
    print(4, end = "")
    for x in range(2*N):
        print(5, end = "")
    print(4, end = "")
    print(3, end = "")
    print(2, end = "")
    print(1, end = "")
    print(0)
    N-=1

    print(0, end = "")
    print(1, end = "")
    print(2, end = "")
    print(3, end = "")
    print(4, end = "")
    print(5, end = "")
    for x in range(2*N):
        print(6, end = "")
    print(5, end = "")
    print(4, end = "")
    print(3, end = "")
    print(2, end = "")
    print(1, end = "")
    print(0)
    N-=1

    print(0, end = "")
    print(1, end = "")
    print(2, end = "")
    print(3, end = "")
    print(4, end = "")
    print(5, end = "")
    print(6, end = "")
    for x in range(2*N):
        print(7, end = "")
    print(6, end = "")
    print(5, end = "")
    print(4, end = "")
    print(3, end = "")
    print(2, end = "")
    print(1, end = "")
    print(0)
    N-=1

    print(0, end = "")
    print(1, end = "")
    print(2, end = "")
    print(3, end = "")
    print(4, end = "")
    print(5, end = "")
    print(6, end = "")
    print(7, end = "")
    for x in range(2*N):
        print(8, end = "")
    print(7, end = "")
    print(6, end = "")
    print(5, end = "")
    print(4, end = "")
    print(3, end = "")
    print(2, end = "")
    print(1, end = "")
    print(0)
    N-=1

    print(0, end = "")
    print(1, end = "")
    print(2, end = "")
    print(3, end = "")
    print(4, end = "")
    print(5, end = "")
    print(6, end = "")
    print(7, end = "")
    print(8, end = "")
    for x in range(2*N):
        print(9, end = "")
    print(8, end = "")
    print(7, end = "")
    print(6, end = "")
    print(5, end = "")
    print(4, end = "")
    print(3, end = "")
    print(2, end = "")
    print(1, end = "")
    print(0)
    N-=1
