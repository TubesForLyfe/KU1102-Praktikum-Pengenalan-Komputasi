# Nama : Willy Wilsen
# NIM : 16520145
# Tanggal : 18 November 2020
# Deskripsi : Membuat program yang mencari panjang dari substring terpanjang yang merupakan palindrom.

# KAMUS
# N : int (Asumsikan lebih dari 0)
# X : str
# i : int (indeks dari X)

# ALGORITMA
N = int(input("Masukkan panjang string: ")) # input N
X = str(input("Masukkan string: ")) # input X

if len(X) == N: # saat sesuai
    i = N//2
    palindrom = True
    while i < N: # mengecek palindrom dimulai dari indeks N//2
        if X[i] != X[N-i-1]: # saat terdapat ketidakpalindroman
            print("Panjangnya adalah", 2*i - N) # print panjang palindrom
            palindrom = False
            i = N # program berhenti
        i += 1 # indeks terus bertambah 1
    if palindrom == True:
        print("Panjangnya adalah", N)
else: # saat tidak sesuai
    print("Maaf, panjang string tidak sesuai")
