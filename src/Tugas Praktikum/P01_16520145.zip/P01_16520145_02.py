# Nama : Willy Wilsen
# NIM : 16520145
# Tanggal : 21 Oktober 2020
# Deskripsi : Membuat program untuk menghitung integral dari f(x) = ax + b

# KAMUS
# a : int
# b : int

# ALGORITMA
a = int(input("Masukkan a: "))
b = int(input("Masukkan b: "))

# integral f(x)
print("Integral dari f(x) adalah", str(a/2), "x^2 +", str(b), "x + C")
