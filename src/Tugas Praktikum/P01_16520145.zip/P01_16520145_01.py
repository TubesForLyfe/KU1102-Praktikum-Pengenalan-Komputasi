# Nama : Willy Wilsen
# NIM : 16520145
# Tanggal : 21 Oktober 2020
# Deskripsi : Membuat program untuk membagi permen kepada 4 anak sama rata

# KAMUS
# a : int
# b : int
# c : int
# d : int

# ALGORITMA
a = int(input("Masukkan nilai a: "))
b = int(input("Masukkan nilai b: "))
c = int(input("Masukkan nilai c: "))
d = int(input("Masukkan nilai d: "))

# pembagian permen
print("Setiap anak akan mendapat", str((a+b+c+d)//4), "permen")
