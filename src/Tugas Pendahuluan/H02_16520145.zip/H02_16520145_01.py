# Nama : Willy Wilsen
# NIM : 16520145
# Tanggal : 1 November 2020
# Deskripsi : Membuat program yang menuliskan 1 sampai N dalam satu baris

# KAMUS
# N : int

# ALGORITMA
N = int(input("Masukkan N: "))
for i in range(1, N+1):
    print(i, end = " ")
