# Nama : Willy Wilsen
# NIM : 16520145
# Tanggal : 16 Oktober 2020
# Deskripsi : Membuat program yang menuliskan Hello, World! ke layar

# KAMUS

# ALGORITMA
print("Hello, World!")
